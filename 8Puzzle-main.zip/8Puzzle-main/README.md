# 8Puzzle

CP468 Assignment 1

## Instructions
To run the program, clone the repository or download all files and run main.py in your IDLE of choice.  
Run main.py and chose the puzzle you wish to run.  


### Heuristics
h1: Number of misplaced tiles   
h2: Sum of Manhattan distances  
h3: Sum of Euclidean distances  
